from pathlib import Path
import numpy as np

def build_image_groups(folder, k_select, method="rmsd"): #"rmsd" or "indices"
    folder = Path(folder)
    files = []
    for file_path in folder.glob("relaxation_*.npz"):
        tag, step = parse_relax_tag(file_path)
        #print(file_path, tag, step)
        files.append((step, tag, file_path))

    groups = []
    gid = 0
    for step, tag, file_path in files:
        with np.load(file_path, mmap_mode="r") as data:
            geoms = data["geoms"]
            energies = data["energies"]
            grads = data["grads"]
            if method == "rmsd":
                idx = select_images_by_rmsd(geoms, k_select)
            elif method == "indices":
                idx = select_images_by_indices(geoms.shape[0], k_select)
            else:
                idx = select_images_by_indices(geoms.shape[0], k_select)
            print(f"idxs selected: {idx} of {len(geoms)}")

            group = []
            for rank, k_in_file in enumerate(idx):
                item = {
                    "gid": gid,
                    "relax_tag": tag,  # "2of5"
                    "file_step": step,
                    "k_in_file": int(k_in_file),  #index inside this npz
                    "select_rank": int(rank),
                    "geom": geoms[k_in_file],
                    "energy": float(energies[k_in_file]),
                    "grad": grads[k_in_file],
                }
                group.append(item)
                gid += 1
            groups.append(group)
    return groups

def parse_relax_tag(file_path):  #relaxation_2of5.npz -> ("2of5", 2)
    stem = file_path.stem
    tag = stem.split("_", 1)[1]

    if tag.endswith("R"):
        return "0R", 0

    if "of" in tag:
        x, _ = tag.split("of", 1)
        return tag, int(x)

    if tag.endswith("P"):
        return tag, int(tag[:-1])

def select_images_by_indices(n_images, k_select):
    if n_images <= k_select:
        return np.arange(n_images, dtype=int)

    idx = np.linspace(0, n_images - 1, k_select)
    idx = idx.round().astype(int)
    idx = np.unique(idx)

    idx[0] = 0
    idx[-1] = n_images - 1
    return idx

def select_images_by_rmsd(images, k_select):
    def rmsd(geom1, geom2):
        diff = geom1 - geom2
        return np.sqrt(np.mean(np.sum(diff * diff, axis=1)))

    n_images = len(images)
    if n_images <= k_select:
        return np.arange(n_images, dtype=int)

    step_distance = np.zeros(n_images - 1)
    for i in range(n_images - 1):
        step_distance[i] = rmsd(images[i], images[i + 1])

    accumulated_distance  = np.zeros(n_images)
    accumulated_distance[1:] = np.cumsum(step_distance)
    total = accumulated_distance[-1]


    if total < 1e-10: #if the difference is minor
        idx = np.linspace(0, n_images - 1, k_select)
        idx = np.round(idx).astype(int)
        idx[0], idx[-1] = 0, n_images - 1
        return np.unique(idx)


    idx = []
    targets = np.linspace(0.0, total, k_select)
    for t in targets:
        j = np.argmin(np.abs(accumulated_distance - t))
        idx.append(j)
    idx = np.array(idx, dtype=int)
    idx[0], idx[-1] = 0, n_images - 1
    idx = np.unique(idx)

    if len(idx) < k_select:
        # print(f"k gets ruduced! {len(idx)} instead of {k_select}")
        all_idx = np.arange(n_images)
        missing = np.setdiff1d(all_idx, idx)

        need = k_select - len(idx)

        selected_s = accumulated_distance[idx]
        candidates = []

        for j in missing:
            dist = np.min(np.abs(accumulated_distance[j] - selected_s))
            candidates.append((dist, j))

        candidates.sort(reverse=True)
        extra = [j for dist, j in candidates[:need]]

        idx = np.sort(np.concatenate([idx, extra]))

    # print(f"Indices are {idx} of {n_images}")


    return idx